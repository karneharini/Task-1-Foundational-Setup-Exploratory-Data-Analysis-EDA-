import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Student Performance Dashboard", layout="wide")

st.title("📊 Student Performance EDA Dashboard")

# Load dataset
df = pd.read_csv("student_performance.csv")

st.sidebar.header("Filter")

department = st.sidebar.multiselect(
    "Select Department",
    df["Department"].unique(),
    default=df["Department"].unique()
)

gender = st.sidebar.multiselect(
    "Select Gender",
    df["Gender"].unique(),
    default=df["Gender"].unique()
)

filtered = df[
    (df["Department"].isin(department)) &
    (df["Gender"].isin(gender))
]

st.subheader("Dataset")
st.dataframe(filtered)

# KPIs
col1, col2, col3 = st.columns(3)

col1.metric("Students", len(filtered))
col2.metric("Average Marks", round(filtered["Marks"].mean(),2))
col3.metric("Average Attendance", round(filtered["Attendance"].mean(),2))

# Department-wise Marks
st.subheader("Average Marks by Department")

dept = filtered.groupby("Department")["Marks"].mean()

fig, ax = plt.subplots()
ax.bar(dept.index, dept.values)
ax.set_xlabel("Department")
ax.set_ylabel("Average Marks")
st.pyplot(fig)

# Gender Distribution
st.subheader("Gender Distribution")

gender_count = filtered["Gender"].value_counts()

fig, ax = plt.subplots()
ax.pie(gender_count.values,
       labels=gender_count.index,
       autopct='%1.1f%%')
st.pyplot(fig)

# Marks Distribution
st.subheader("Marks Distribution")

fig, ax = plt.subplots()
ax.hist(filtered["Marks"], bins=5)
ax.set_xlabel("Marks")
ax.set_ylabel("Students")
st.pyplot(fig)

# Correlation
st.subheader("Correlation Matrix")
st.write(filtered[["Attendance","Study_Hours","Marks"]].corr())

# Download
csv = filtered.to_csv(index=False).encode("utf-8")

st.download_button(
    "Download Filtered Data",
    csv,
    "filtered_students.csv",
    "text/csv"
)